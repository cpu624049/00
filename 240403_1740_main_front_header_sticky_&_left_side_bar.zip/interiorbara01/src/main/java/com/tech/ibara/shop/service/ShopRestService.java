package com.tech.ibara.shop.service;

public interface ShopRestService<T> extends ShopService {

	public T getData();
}
