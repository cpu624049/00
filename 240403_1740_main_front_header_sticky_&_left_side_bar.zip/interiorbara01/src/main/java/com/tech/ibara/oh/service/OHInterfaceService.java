package com.tech.ibara.oh.service;

import org.springframework.ui.Model;

public interface OHInterfaceService {
	public void execute(Model model);
}
