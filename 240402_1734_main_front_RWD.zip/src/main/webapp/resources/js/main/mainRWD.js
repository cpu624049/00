/* RWD (Responsive Web Design, 반응형 웹 디자인) */

window.addEventListener('resize', function() {
	var screenWidth = window.innerWidth;
	var contents = document.querySelectorAll('.main_preview_wrap');

	// Show all contents
	contents.forEach(function(content) {
		content.style.display = 'block';
	});

	// Hide 4th contents if screen width is less than 1440px
	var thirdContent = document.querySelector('.main_preview_biz_list:nth-child(3)');
	var fourthContent = document.querySelector('.main_preview_biz_list:nth-child(4)');

	if (1201 <= screenWidth && screenWidth < 1600) {
		fourthContent.style.display = 'none';
	}
	// Hide 3rd and 4th contents if screen width is less than 1024px
	else if (screenWidth < 1201) {
		thirdContent.style.display = 'none';
		fourthContent.style.display = 'none';
	}
	// Re-display 3rd and 4th contents if screen width is greater than 1024px
	else {
		thirdContent.style.display = 'block';
		fourthContent.style.display = 'block';
	}
});
