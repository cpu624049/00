package com.tech.ibara.biz.service;

import org.springframework.ui.Model;

public interface BizServiceInter {

	public void execute (Model model);
	
}
