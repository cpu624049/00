package com.tech.ibara.shop.service;

import org.springframework.ui.Model;

public interface ShopService {

	public void execute(Model model);
}
