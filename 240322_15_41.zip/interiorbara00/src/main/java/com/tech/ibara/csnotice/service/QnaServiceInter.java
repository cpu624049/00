package com.tech.ibara.csnotice.service;

import org.springframework.ui.Model;

public interface QnaServiceInter {

	void execute(Model model);
}
