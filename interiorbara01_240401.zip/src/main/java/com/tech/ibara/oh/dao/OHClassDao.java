package com.tech.ibara.oh.dao;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class OHClassDao {
	
	// Servers > context.xml - 설정 X
//	DataSource dataSource;	
//	public OHClassDao() {
//		System.out.println("OHClassDao() DB접속 생성자");
//		try {
//			Context context = new InitialContext();
//			dataSource = context.lookup("java:comp/env/jdbc/springxe");
//			System.out.println("DB Connection Success");
//		} catch (Exception e) {
//			System.out.println("DB Connection failed");
//		}
//	}
	
	
	
	
}
