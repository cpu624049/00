package com.tech.ibara.oh.service;

import org.springframework.ui.Model;

public class OHPhotoEditExecuteService implements OHInterfaceService {

	@Override
	public void execute(Model model) {
		System.out.println("OHPhotoEditExecuteService");
		
	}
	
}
