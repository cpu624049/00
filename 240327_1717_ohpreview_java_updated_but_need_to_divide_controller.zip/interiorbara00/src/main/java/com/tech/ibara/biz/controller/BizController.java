package com.tech.ibara.biz.controller;

import org.springframework.stereotype.Controller;

@Controller
public class BizController {

}
