package com.tech.ibara.shop.dto;

public class TestDto {

}
