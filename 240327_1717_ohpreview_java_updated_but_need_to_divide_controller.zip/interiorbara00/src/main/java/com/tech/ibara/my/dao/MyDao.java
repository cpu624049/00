//package com.tech.ibara.my.dao;
//
////import com.tech.ibara.my.dto.IdJoinDto;
//
//public interface MyDao {
//	public void join(String idnickname,String shpwd,String bcpwd,String email);
//	public Integer emailCheck(String email);
//	public Integer nicknameCheck(String nickname);
//	public int idnoSearch(String nickname);
//	public String getMemberEmail(int idno);
//	public void setMemberEmailChecked(int idno);
////	public IdJoinDto getMember(String email);
//
//}
