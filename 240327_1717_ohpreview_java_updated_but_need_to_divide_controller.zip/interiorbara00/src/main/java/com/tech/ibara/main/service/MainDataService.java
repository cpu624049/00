package com.tech.ibara.main.service;

import org.springframework.ui.Model;

public interface MainDataService {

	public void execute(Model model);

}
