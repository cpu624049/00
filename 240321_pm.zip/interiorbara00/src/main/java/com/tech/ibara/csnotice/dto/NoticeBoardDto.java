package com.tech.ibara.csnotice.dto;

public class NoticeBoardDto {

}
