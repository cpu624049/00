package com.tech.ibara.biz.service;

public class BizProSearchService {

}
