package com.tech.ibara.main.dto;

public interface MainSearchDto {

}
