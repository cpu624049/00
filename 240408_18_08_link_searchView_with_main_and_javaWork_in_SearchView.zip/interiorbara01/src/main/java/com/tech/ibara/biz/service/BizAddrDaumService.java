package com.tech.ibara.biz.service;

public class BizAddrDaumService {

}
