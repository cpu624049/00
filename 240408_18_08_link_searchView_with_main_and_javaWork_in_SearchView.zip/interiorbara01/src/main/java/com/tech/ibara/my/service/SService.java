package com.tech.ibara.my.service;

import org.springframework.ui.Model;

public interface SService {
	public String execute(Model model);
}
