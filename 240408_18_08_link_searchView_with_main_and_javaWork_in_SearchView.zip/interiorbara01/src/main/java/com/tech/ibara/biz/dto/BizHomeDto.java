package com.tech.ibara.biz.dto;

public class BizHomeDto {

	private int bh_no;
	private String bh_img;
	private String bh_notice;
	private String bh_intro;
	private String bh_name;
	private int bh_like;
	private int bh_cont_cnt;
	private String bh_pro;
	private String bh_addr1;
	private String bh_addr2;
	private int biz_idno;
	
	public int getBh_no() {
		return bh_no;
	}
	public void setBh_no(int bh_no) {
		this.bh_no = bh_no;
	}
	public String getBh_img() {
		return bh_img;
	}
	public void setBh_img(String bh_img) {
		this.bh_img = bh_img;
	}
	public String getBh_notice() {
		return bh_notice;
	}
	public void setBh_notice(String bh_notice) {
		this.bh_notice = bh_notice;
	}
	public String getBh_intro() {
		return bh_intro;
	}
	public void setBh_intro(String bh_intro) {
		this.bh_intro = bh_intro;
	}
	public String getBh_name() {
		return bh_name;
	}
	public void setBh_name(String bh_name) {
		this.bh_name = bh_name;
	}
	public int getBh_like() {
		return bh_like;
	}
	public void setBh_like(int bh_like) {
		this.bh_like = bh_like;
	}
	public int getBh_cont_cnt() {
		return bh_cont_cnt;
	}
	public void setBh_cont_cnt(int bh_cont_cnt) {
		this.bh_cont_cnt = bh_cont_cnt;
	}
	public String getBh_pro() {
		return bh_pro;
	}
	public void setBh_pro(String bh_pro) {
		this.bh_pro = bh_pro;
	}
	public String getBh_addr1() {
		return bh_addr1;
	}
	public void setBh_addr1(String bh_addr1) {
		this.bh_addr1 = bh_addr1;
	}
	public String getBh_addr2() {
		return bh_addr2;
	}
	public void setBh_addr2(String bh_addr2) {
		this.bh_addr2 = bh_addr2;
	}
	public int getBiz_idno() {
		return biz_idno;
	}
	public void setBiz_idno(int biz_idno) {
		this.biz_idno = biz_idno;
	}
	
}
