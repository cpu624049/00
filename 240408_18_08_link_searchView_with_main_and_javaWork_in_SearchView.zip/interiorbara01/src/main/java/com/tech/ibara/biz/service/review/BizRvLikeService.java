package com.tech.ibara.biz.service.review;

public class BizRvLikeService {

}
