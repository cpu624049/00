package com.tech.ibara.my.service;

import org.springframework.ui.Model;

public interface VService {
	public void execute(Model model);
}
