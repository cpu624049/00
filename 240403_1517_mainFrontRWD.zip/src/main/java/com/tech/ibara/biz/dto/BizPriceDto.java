package com.tech.ibara.biz.dto;

public class BizPriceDto {

	private int bp_no;
	private String bp_name;
	private String bp_content;
	private int bp_price;
	private String bp_category;
	private String bp_type;
	private String bp_img;
	private int biz_idno;
	
	
	public int getBp_no() {
		return bp_no;
	}
	public void setBp_no(int bp_no) {
		this.bp_no = bp_no;
	}
	public String getBp_name() {
		return bp_name;
	}
	public void setBp_name(String bp_name) {
		this.bp_name = bp_name;
	}
	public String getBp_content() {
		return bp_content;
	}
	public void setBp_content(String bp_content) {
		this.bp_content = bp_content;
	}
	public int getBp_price() {
		return bp_price;
	}
	public void setBp_price(int bp_price) {
		this.bp_price = bp_price;
	}
	public String getBp_category() {
		return bp_category;
	}
	public void setBp_category(String bp_category) {
		this.bp_category = bp_category;
	}
	public String getBp_type() {
		return bp_type;
	}
	public void setBp_type(String bp_type) {
		this.bp_type = bp_type;
	}
	public String getBp_img() {
		return bp_img;
	}
	public void setBp_img(String bp_img) {
		this.bp_img = bp_img;
	}
	public int getBiz_idno() {
		return biz_idno;
	}
	public void setBiz_idno(int biz_idno) {
		this.biz_idno = biz_idno;
	}
	
}
