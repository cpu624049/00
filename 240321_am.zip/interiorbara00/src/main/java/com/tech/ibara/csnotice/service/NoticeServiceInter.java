package com.tech.ibara.csnotice.service;

import org.springframework.ui.Model;

public interface NoticeServiceInter {

	void execute(Model model);
}
