package com.tech.ibara.csnotice.dao;

import java.util.ArrayList;

import com.tech.ibara.csnotice.dto.QnaDto;

public interface NoticeBoardIDao {

	public ArrayList<QnaDto> noticelist();
	
}
