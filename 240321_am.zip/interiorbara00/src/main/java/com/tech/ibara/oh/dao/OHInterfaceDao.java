package com.tech.ibara.oh.dao;

import java.util.ArrayList;

import com.tech.ibara.oh.dto.OHPhotoBoard;

public interface OHInterfaceDao {
	
	// OHPhotoView.jsp
	public ArrayList<OHPhotoBoard> ohPhotoView();
	
}
