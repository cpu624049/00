package com.tech.ibara.my.controller;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController {
//	SCommand scommand;
	
	@Autowired
	private SqlSession sqlSession;
	
	@RequestMapping("/join/joinform")
	public String joinform(Model model) {
		System.out.println("joinform()");
		return "/join/joinform";
	}
}