package com.tech.ibara.csnotice.service;

public interface QnaInter {

}
