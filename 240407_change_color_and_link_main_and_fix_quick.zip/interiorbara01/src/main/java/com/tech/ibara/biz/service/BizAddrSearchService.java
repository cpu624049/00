package com.tech.ibara.biz.service;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

@Service
public class BizAddrSearchService implements BizServiceInter {

	@Override
	public void execute(Model model) {
		// TODO Auto-generated method stub
		/*
		System.out.println("BizAddrSearchService>>>>>>>");

		Map<String, Object> map=model.asMap();
		HttpServletRequest request=(HttpServletRequest)map.get("request");
		BizSearchVO searchVO=(BizSearchVO)map.get("searchVO");
		SqlSession sqlSession=(SqlSession)map.get("sqlSession");
		
		BizIDao dao=sqlSession.getMapper(BizIDao.class);*/
		
		
		
	}

}
