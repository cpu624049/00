package com.tech.ibara.modal.dto;

public class ModalCheckDto {

	private String m_type; 
	private String m_pname; 
	private String m_pexp; 
	private int m_pprice;
	
	
	public String getM_type() {
		return m_type;
	}
	public void setM_type(String m_type) {
		this.m_type = m_type;
	}
	public String getM_pname() {
		return m_pname;
	}
	public void setM_pname(String m_pname) {
		this.m_pname = m_pname;
	}
	public String getM_pexp() {
		return m_pexp;
	}
	public void setM_pexp(String m_pexp) {
		this.m_pexp = m_pexp;
	}
	public int getM_pprice() {
		return m_pprice;
	}
	public void setM_pprice(int m_pprice) {
		this.m_pprice = m_pprice;
	} 
	

}
