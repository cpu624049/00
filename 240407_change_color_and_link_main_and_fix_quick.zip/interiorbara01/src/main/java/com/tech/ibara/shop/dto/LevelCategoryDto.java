package com.tech.ibara.shop.dto;

public class LevelCategoryDto extends CategoryDto {

	private int level;

	public LevelCategoryDto() {
		super();
	}
	
	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

}
