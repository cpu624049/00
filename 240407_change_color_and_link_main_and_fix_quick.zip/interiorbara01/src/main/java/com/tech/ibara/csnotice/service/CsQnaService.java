package com.tech.ibara.csnotice.service;

import org.springframework.ui.Model;

public interface CsQnaService {

	public void execute(Model model);
}
