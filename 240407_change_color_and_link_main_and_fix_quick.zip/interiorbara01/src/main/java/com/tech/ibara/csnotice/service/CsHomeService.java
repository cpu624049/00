package com.tech.ibara.csnotice.service;

import org.springframework.ui.Model;

public interface CsHomeService {

	public void execute(Model model);
}
