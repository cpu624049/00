--------------------------------------------------------------------------------
-- TABLE: OH_PHOTO_BOARD
--------------------------------------
-- CREATE
CREATE TABLE OH_PHOTO_BOARD (
    PB_NO		      NUMBER PRIMARY KEY,   -- 번호
  
    MEMNO	          NUMBER,               -- 사용자_번호, FOREIGN KEY
                                            -- TABLE: my_member_info, COLUMN: memno

    PB_TITLE	      VARCHAR2(100),        -- 제목
    PB_CONTENT	      VARCHAR2(650),        -- 내용
    PB_DATE		      DATE DEFAULT SYSDATE, -- 날짜
    PB_LIKE		      NUMBER DEFAULT 0,     -- 좋아요수
    PB_SCRAP	      NUMBER DEFAULT 0,     -- 스크랩수
    PB_REPLY	      NUMBER DEFAULT 0,     -- 댓글수
    PB_LINK		      NUMBER DEFAULT 0,     -- 공유수
    PB_HIT		      NUMBER DEFAULT 0,     -- 조회수
    PB_CATEGORY	      VARCHAR2(50),         -- #카테고리
    PB_RESIDENCE      VARCHAR2(50),         -- 주거형태
    PB_ROOM		      VARCHAR2(50),         -- 공간
    PB_STYLE		  VARCHAR2(50),         -- 스타일
    PB_SKILL		  VARCHAR2(50)          -- 셀프/전문가
);
--------------------------------------
-- DROP
DROP TABLE OH_PHOTO_BOARD;
DROP TABLE OH_PHOTO_BOARD PURGE;
--------------------------------------
-- SEQUENCE
CREATE SEQUENCE OH_PHOTO_BOARD_SEQ;
DROP SEQUENCE OH_PHOTO_BOARD_SEQ;
--------------------------------------
-- INSERT
INSERT INTO OH_PHOTO_BOARD VALUES (OH_PHOTO_BOARD_SEQ.NEXTVAL, '1', '제목입니다.', '내용입니다....', SYSDATE, 0, 0, 0, 0, 0, '#그냥', '아파트', '거실', '빈티지', '셀프');
INSERT INTO OH_PHOTO_BOARD VALUES (OH_PHOTO_BOARD_SEQ.NEXTVAL, '2', '제목입니다.', '내용입니다....', SYSDATE, 0, 0, 0, 0, 0, '#그냥', '아파트', '거실', '빈티지', '셀프');
INSERT INTO OH_PHOTO_BOARD VALUES (OH_PHOTO_BOARD_SEQ.NEXTVAL, '3', '제목입니다.', '내용입니다....', SYSDATE, 0, 0, 0, 0, 0, '#그냥', '아파트', '거실', '빈티지', '셀프');
INSERT INTO OH_PHOTO_BOARD VALUES (OH_PHOTO_BOARD_SEQ.NEXTVAL, '4', '제목입니다.', '내용입니다....', SYSDATE, 0, 0, 0, 0, 0, '#그냥', '아파트', '거실', '빈티지', '셀프');
INSERT INTO OH_PHOTO_BOARD VALUES (OH_PHOTO_BOARD_SEQ.NEXTVAL, '1', '제목입니다.', '내용입니다....', SYSDATE, 0, 0, 0, 0, 0, '#그냥', '아파트', '거실', '빈티지', '셀프');
INSERT INTO OH_PHOTO_BOARD VALUES (OH_PHOTO_BOARD_SEQ.NEXTVAL, '2', '제목입니다.', '내용입니다....', SYSDATE, 0, 0, 0, 0, 0, '#그냥', '아파트', '거실', '빈티지', '셀프');
INSERT INTO OH_PHOTO_BOARD VALUES (OH_PHOTO_BOARD_SEQ.NEXTVAL, '3', '제목입니다.', '내용입니다....', SYSDATE, 0, 0, 0, 0, 0, '#그냥', '아파트', '거실', '빈티지', '셀프');
INSERT INTO OH_PHOTO_BOARD VALUES (OH_PHOTO_BOARD_SEQ.NEXTVAL, '4', '제목입니다.', '내용입니다....', SYSDATE, 0, 0, 0, 0, 0, '#그냥', '아파트', '거실', '빈티지', '셀프');                                   
--------------------------------------
--------------------------------------------------------------------------------
-- TABLE: OH_PHOTO_ATTACH
--------------------------------------
-- CREATE 
CREATE TABLE OH_PHOTO_ATTACH (
    PA_NO       NUMBER PRIMARY KEY,   -- 번호
    PA_ATTACH   VARCHAR2(100),        -- 사진첨부
    PB_NO       NUMBER CONSTRAINT     -- 번호(OH_PHOTO_BOARD)     
                           PA_PB_NO_FK
                       REFERENCES 
                           OH_PHOTO_BOARD(PB_NO) 
                       ON DELETE CASCADE 
);
--------------------------------------
-- CONSTRAINT
SELECT * FROM ALL_CONSTRAINTS WHERE TABLE_NAME = 'OH_PHOTO_ATTACH';
ALTER TABLE OH_PHOTO_ATTACH DROP CONSTRAINT PA_PB_NO_FK;
--------------------------------------
-- DROP
DROP TABLE OH_PHOTO_ATTACH;
DROP TABLE OH_PHOTO_ATTACH PURGE;
-------------------------------------
-- SEQUENCE-
CREATE SEQUENCE OH_PHOTO_ATTACH_SEQ;
DROP SEQUENCE OH_PHOTO_ATTACH_SEQ;
--------------------------------------
-- INSERT
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_01234567890123456789012345678901234567890123456789');
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789');
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456');
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456as');
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_한글입니다한글입니다한글입니다한글입니다한글입니다한글입니다');
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_한글입니다한글입니다한글입니다한글입니다한글입니다한글입니');
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_한글입니다한글입니다한글입니다한글입니다한글입니다한글입');
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_한글입니다한글입니다한글입니다한글입니다한글입니다한글');
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_한글입니다한글입니다한글입니다한글입니다한글입니다한');
INSERT INTO OH_PHOTO_ATTACH (PA_NO, PA_ATTACH) VALUES (OH_PHOTO_ATTACH_SEQ.NEXTVAL, '1712807303308_한글입니다한글입니다한글입니다한글입니다한글입니다');
--------------------------------------
--------------------------------------------------------------------------------
-- TABLE: OH_PHOTO_LIKE
--------------------------------------
-- CREATE
CREATE TABLE OH_PHOTO_LIKE (
    PL_NO             NUMBER PRIMARY KEY,    -- 번호

    MEMNO	          NUMBER,                -- 사용자_번호, FOREIGN KEY
                                             -- TABLE: my_member_info, COLUMN: memno

    PL_DATE           DATE DEFAULT SYSDATE,  -- 날짜
    PB_NO             NUMBER CONSTRAINT      -- 번호(OH_PHOTO_BOARD)     
                                PL_PB_NO_FK
                             REFERENCES 
                                OH_PHOTO_BOARD(PB_NO) 
                             ON DELETE CASCADE 
);
--------------------------------------
-- CONSTRAINT
SELECT * FROM ALL_CONSTRAINTS WHERE TABLE_NAME = 'OH_PHOTO_LIKE';
ALTER TABLE OH_PHOTO_LIKE DROP CONSTRAINT PL_PB_NO_FK;
--------------------------------------
-- DROP
DROP TABLE OH_PHOTO_LIKE;
DROP TABLE OH_PHOTO_LIKE PURGE;
--------------------------------------
-- SEQUENCE
CREATE SEQUENCE OH_PHOTO_LIKE_SEQ;
DROP SEQUENCE OH_PHOTO_LIKE_SEQ;
--------------------------------------
-- INSERT

--------------------------------------
--------------------------------------------------------------------------------
-- TABLE: OH_PHOTO_SCRAP
--------------------------------------
-- CREATE
CREATE TABLE OH_PHOTO_SCRAP (
    PS_NO             NUMBER PRIMARY KEY,     -- 번호

    MEMNO	          NUMBER,                 -- 사용자_번호, FOREIGN KEY
                                              -- TABLE: my_member_info, COLUMN: memno
                                         
    PS_DATE           DATE DEFAULT SYSDATE,   -- 날짜
    PB_NO             NUMBER CONSTRAINT       -- 번호(OH_PHOTO_BOARD)     
                                PS_PB_NO_FK
                             REFERENCES 
                                OH_PHOTO_BOARD(PB_NO) 
                             ON DELETE CASCADE 
);
--------------------------------------
-- CONSTRAINT
SELECT * FROM ALL_CONSTRAINTS WHERE TABLE_NAME = 'OH_PHOTO_SCRAP';
ALTER TABLE OH_PHOTO_SCRAP DROP CONSTRAINT PS_PB_NO_FK;
--------------------------------------
-- DROP
DROP TABLE OH_PHOTO_SCRAP;
DROP TABLE OH_PHOTO_SCRAP PURGE;
--------------------------------------
-- SEQUENCE
CREATE SEQUENCE OH_PHOTO_SCRAP_SEQ;
DROP SEQUENCE OH_PHOTO_SCRAP_SEQ;
--------------------------------------
-- INSERT

--------------------------------------
--------------------------------------------------------------------------------
-- TABLE: OH_PHOTO_REPLY
--------------------------------------
-- CREATE
CREATE TABLE OH_PHOTO_REPLY (
    PR_NO              NUMBER PRIMARY KEY,    -- 번호

    MEMNO	           NUMBER,                -- 사용자_번호, FOREIGN KEY
                                              -- TABLE: my_member_info, COLUMN: memno

    PR_CONTENT         VARCHAR2(200),         -- 내용
    PR_DATE            DATE DEFAULT SYSDATE,  -- 날짜
    PR_GROUP           NUMBER,                -- GROUP
    PR_STEP            NUMBER,                -- STEP
    PR_INDENT          NUMBER,                -- INDENT
    PB_NO              NUMBER CONSTRAINT      -- 번호(OH_PHOTO_BOARD)     
                                PR_PB_NO_FK
                              REFERENCES 
                                OH_PHOTO_BOARD(PB_NO) 
                              ON DELETE CASCADE 
);
--------------------------------------
-- CONSTRAINT
SELECT * FROM ALL_CONSTRAINTS WHERE TABLE_NAME = 'OH_PHOTO_REPLY';
ALTER TABLE OH_PHOTO_REPLY DROP CONSTRAINT PR_PB_NO_FK;
--------------------------------------
-- DROP
DROP TABLE OH_PHOTO_REPLY;
DROP TABLE OH_PHOTO_REPLY PURGE;
--------------------------------------
-- SEQUENCE
CREATE SEQUENCE OH_PHOTO_REPLY_SEQ;
DROP SEQUENCE OH_PHOTO_REPLY_SEQ;
--------------------------------------
-- INSERT
INSERT INTO OH_PHOTO_REPLY (PR_NO, MEMNO, PR_CONTENT, PR_DATE, PR_GROUP, PR_STEP, PR_INDENT, PB_NO) VALUES (OH_PHOTO_REPLY_SEQ.NEXTVAL, 1, '댓글내용', SYSDATE, 0, 0, 0, 118);
--------------------------------------
--------------------------------------------------------------------------------
-- TABLE: OH_PHOTO_REPLY_LIKE
--------------------------------------
-- CREATE
CREATE TABLE OH_PHOTO_REPLY_LIKE (
    PRL_NO             NUMBER PRIMARY KEY,     -- 번호
    
    MEMNO	           NUMBER,                 -- 사용자_번호, FOREIGN KEY
                                               -- TABLE: my_member_info, COLUMN: memno

    PRL_DATE           DATE DEFAULT SYSDATE,   -- 날짜
    PR_NO              NUMBER CONSTRAINT       -- 번호(OH_PHOTO_REPLY)
                                PRL_PR_NO_FK
                              REFERENCES
                                OH_PHOTO_REPLY(PR_NO)
                              ON DELETE CASCADE
);
--------------------------------------
-- CONSTRAINT
SELECT * FROM ALL_CONSTRAINTS WHERE TABLE_NAME = 'OH_PHOTO_REPLY_LIKE';
ALTER TABLE OH_PHOTO_REPLY_LIKE DROP CONSTRAINT PRL_PR_NO_FK;
--------------------------------------
-- DROP
DROP TABLE OH_PHOTO_REPLY_LIKE;
DROP TABLE OH_PHOTO_REPLY_LIKE PURGE;
--------------------------------------
-- SEQUENCE
CREATE SEQUENCE OH_PHOTO_REPLY_LIKE_SEQ;
DROP SEQUENCE OH_PHOTO_REPLY_LIKE_SEQ;
--------------------------------------
-- INSERT
INSERT INTO OH_PHOTO_REPLY_LIKE (PRL_NO, MEMNO, PRL_DATE) VALUES (OH_PHOTO_REPLY_LIKE_SEQ.NEXTVAL, 3, SYSDATE);
--------------------------------------

