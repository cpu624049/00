package com.tech.ibara.main.service;

public class QnAPreviewService {

}
