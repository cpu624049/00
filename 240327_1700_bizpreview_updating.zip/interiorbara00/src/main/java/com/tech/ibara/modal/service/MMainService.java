package com.tech.ibara.modal.service;

public class MMainService {

}
