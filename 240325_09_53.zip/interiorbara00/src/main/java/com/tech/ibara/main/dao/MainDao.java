package com.tech.ibara.main.dao;

import java.util.ArrayList;

import com.tech.ibara.main.dto.BizPreviewDto;

public interface MainDao {
	ArrayList<BizPreviewDto> bizPreview();
}
