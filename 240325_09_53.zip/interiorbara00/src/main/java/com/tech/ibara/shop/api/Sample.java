package com.tech.ibara.shop.api;

public class Sample {

}
